import './App.css'
import Dashboard from './Dashboard/Dashboard'
import Navbar from './Navbar/Components/SideNav'
import Topnav from './Navbar/Components/Topnav'
import Navbars from './Navbar/Navbar'

function App() {

  return (
    <>
      <div className="back-pg">
        <Topnav/>
        <Navbar/>
        <div className="runing-pg">
          <Dashboard/>
        </div>
      </div>
    </>
  )
}

export default App
