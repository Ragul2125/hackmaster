import './Navbar.css'
import Sidenav from './Components/SideNav'
import Topnav from './Components/Topnav'

export default function Navbars() {
    return (
        <>
           <div className="nav-pg">
           <Topnav />
            <Sidenav />
           </div>
        </>
    )
}